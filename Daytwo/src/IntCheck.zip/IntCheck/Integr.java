package IntCheck;
import java.util.Date;
import java.util.Scanner;
public class Integr extends Exception{
	String message="";
	public Integr(String mesg)
	{
		message=mesg;
	}
	public String getMessage()
	{
		return message;
	}
	public Integr()
	{
	}
	@Override
	public String toString()
	{
		return this.getClass().getName()+ new Date()+"";
	}
}
class greaterException
{
	int num;
	int flag=0;
	public void validate(greaterException gE) throws Integr
	{
		if(gE.num>this.num)
		{
		throw new Integr("Value of second class greater  is");
		}
		else
		{
			throw new Integr("Value of the first class less is");
		}
	}
	public void accept()
	{
		greaterException obj1=new greaterException();
		greaterException obj2=new greaterException();
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter first number");
		obj1.num=sc.nextInt();
		System.out.println("Please enter second number");
		obj2.num=sc.nextInt();
		try
		{
			obj1.validate(obj2);
		}
		catch(Integr k)
		{
			System.out.println("  "+k+obj1.num);
		}
		finally
		{
			System.out.println("Finished_Problem_3");
		}
	}
}