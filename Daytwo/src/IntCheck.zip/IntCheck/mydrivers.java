package IntCheck;

public class mydrivers {

	public static void main(String[] args) {
			
			// TODO Auto-generated method stub
	greaterException gobj=new greaterException();
	gobj.accept();

		// TODO Auto-generated method stub

	}

}
