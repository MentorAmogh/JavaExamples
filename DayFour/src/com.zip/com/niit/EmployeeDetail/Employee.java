package com.niit.EmployeeDetail;

public class Employee {

	public int sumUp(int first, int second) {
		// TODO Auto-generated method stub
		return first+second;
	}

	public boolean compareStrings(String sfirst, String ssecond) {
		// TODO Auto-generated method stub
		if(sfirst.equals(ssecond))
		return true;
		else
		return false;
	}

	public double compareDouble(double dfirst, double dsecond) {
		// TODO Auto-generated method stub
		return dfirst+dsecond;
	}

}
